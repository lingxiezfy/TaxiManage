CREATE PROCEDURE get_admin_page_list(IN a_id_in   INT, IN a_t_id_in INT, IN cpn_id_in INT, IN curr_page INT,
                                     IN page_size INT, IN a_t_id_s_in INT)
  BEGIN
  DECLARE s INT;
  SET s = (curr_page-1)*page_size;
  if a_t_id_in < 3 THEN
    if a_t_id_s_in = 0 THEN
      SELECT t_admin.*,t_a_type.a_t_name FROM t_admin,t_a_type WHERE
        t_admin.a_t_id = t_a_type.a_t_id AND
        t_admin.a_t_id >= a_t_id_in AND
        t_admin.a_id != a_id_in ORDER BY t_admin.a_t_id,t_admin.a_count LIMIT s,page_size;
    ELSEif a_t_id_s_in = 3 THEN
            SELECT t_admin.*,t_a_type.a_t_name FROM t_admin,t_a_type,t_cpn_admin WHERE
              t_admin.a_t_id = t_a_type.a_t_id AND
                t_admin.a_id = t_cpn_admin.a_id AND
                t_admin.a_t_id >= a_t_id_in AND
                t_admin.a_t_id = a_t_id_s_in AND
                t_admin.a_id != a_id_in ORDER BY t_cpn_admin.cpn_id,t_admin.a_count LIMIT s,page_size;
    ELSE SELECT t_admin.*,t_a_type.a_t_name FROM t_admin,t_a_type WHERE
        t_admin.a_t_id = t_a_type.a_t_id AND
        t_admin.a_t_id >= a_t_id_in AND
        t_admin.a_t_id = a_t_id_s_in AND
        t_admin.a_id != a_id_in ORDER BY t_admin.a_t_id,t_admin.a_count LIMIT s,page_size;

    END IF ;
  ELSE
    SELECT t_admin.*,t_a_type.a_t_name FROM t_admin,t_a_type,t_cpn_admin
    WHERE t_admin.a_t_id = t_a_type.a_t_id AND
          t_admin.a_id = t_cpn_admin.a_id AND
          t_cpn_admin.cpn_id = cpn_id_in AND
          t_admin.a_id != a_id_in ORDER BY t_admin.a_count LIMIT s,page_size;
  END IF ;
END;
