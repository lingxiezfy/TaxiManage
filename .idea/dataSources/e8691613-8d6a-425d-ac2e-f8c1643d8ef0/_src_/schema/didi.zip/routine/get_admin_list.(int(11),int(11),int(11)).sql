CREATE PROCEDURE get_admin_list(IN a_id_in INT, IN a_t_id_in INT, IN cpn_id_in INT)
  BEGIN
    CASE a_t_id_in
      WHEN 1 THEN SELECT a_id,t_admin.a_t_id,a_count,a_password,a_t_name FROM t_admin,t_a_type
        WHERE a_id != a_id_in AND t_admin.a_t_id = t_a_type.a_t_id ORDER BY t_admin.a_t_id;
      WHEN 2 THEN SELECT a_id,t_admin.a_t_id,a_count,a_password,a_t_name FROM t_admin,t_a_type WHERE t_admin.a_id != a_id_in AND t_admin.a_t_id > 1 and t_admin.a_t_id = t_a_type.a_t_id
                  ORDER BY t_admin.a_t_id;
      WHEN 3 THEN
      SELECT t_admin.*,t_a_type.a_t_name,t_company.* FROM t_admin,t_a_type,t_company,t_cpn_admin
      WHERE t_admin.a_t_id = t_a_type.a_t_id AND
            t_admin.a_id = t_cpn_admin.a_id AND
            t_cpn_admin.cpn_id = t_company.cpn_id AND
            t_company.cpn_id = cpn_id_in AND t_admin.a_id != a_id_in
            ORDER BY a_t_id;
      END CASE ;
  END;
