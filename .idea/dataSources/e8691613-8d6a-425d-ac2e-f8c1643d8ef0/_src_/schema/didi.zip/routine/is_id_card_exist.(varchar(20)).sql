CREATE PROCEDURE is_id_card_exist(IN id_card_in VARCHAR(20))
  BEGIN
    DECLARE result BOOLEAN;

    if((SELECT count(*) FROM t_user WHERE u_id_card_number = trim(id_card_in))>0)
    THEN SET result = TRUE ;
    ELSE SET result=FALSE ;
    END IF ;
    SELECT result;
  END;
