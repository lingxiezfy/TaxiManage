CREATE PROCEDURE get_car_host(IN c_id_in INT)
  BEGIN
    if(c_id_in in (SELECT c_id FROM t_private_car)) THEN
      SELECT t_driver.u_id ,t_driver.d_real_name , '1' AS type FROM 
        t_driver ,t_private_car WHERE 
        t_private_car.u_id = t_driver.u_id AND 
          t_private_car.c_id = c_id_in;
    ELSE 
        SELECT t_company.cpn_id,t_company.cpn_name ,'2' as type FROM 
          t_company,t_cpn_car WHERE 
          t_cpn_car.cpn_id = t_company.cpn_id AND 
            t_cpn_car.c_id = c_id_in;
    END IF ;
  END;
