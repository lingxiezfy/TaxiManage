CREATE PROCEDURE register_admin(IN a_t_id_in INT, IN a_count_in VARCHAR(20), IN a_pwd_in VARCHAR(15), IN cpn_id_in INT)
  BEGIN
    DECLARE result INT;
    DECLARE a_id_temp INT;
    INSERT INTO t_admin(a_t_id, a_count, a_password)
      VALUES (a_t_id_in,a_count_in,a_pwd_in);

    if(cpn_id_in > 0 && a_t_id_in = 3) THEN
      SELECT a_id INTO a_id_temp FROM t_admin WHERE a_count = a_count_in;
      if(a_id_temp > 0) THEN
        INSERT INTO t_cpn_admin(a_id, cpn_id) VALUES (a_id_temp,cpn_id_in);

      END IF ;
    END IF ;
    SET result = row_count();
    SELECT result;
  END;
