CREATE PROCEDURE get_driver_list_count(IN cpn_id_in INT, IN d_state_s INT, IN d_real_name_s VARCHAR(20))
  BEGIN
    DECLARE result INT;
    IF cpn_id_in = 0 THEN
      IF d_state_s = 0 THEN
        SELECT count(*) INTO result FROM t_user,t_driver WHERE
          t_user.u_id = t_driver.u_id AND
          t_driver.d_real_name LIKE concat('%',d_real_name_s,'%') ;
      ELSE
        SELECT count(*) INTO result FROM t_user,t_driver WHERE
          t_user.u_id = t_driver.u_id AND t_driver.d_state = d_state_s AND
          t_driver.d_real_name LIKE concat('%',d_real_name_s,'%') ;
      END IF ;
    ELSE
      IF d_state_s = 0 THEN
        SELECT count(*) INTO result FROM t_user,t_driver,t_employee WHERE
          t_user.u_id = t_driver.u_id AND
          t_driver.d_real_name LIKE concat('%',d_real_name_s,'%') AND
          t_driver.u_id = t_employee.u_id AND
          t_employee.cpn_id = cpn_id_in ;
      ELSE
        SELECT count(*) INTO result FROM t_user,t_driver,t_employee WHERE
          t_user.u_id = t_driver.u_id AND
          t_driver.d_real_name LIKE concat('%',d_real_name_s,'%') AND
          t_driver.d_state = d_state_s AND
          t_driver.u_id = t_employee.u_id AND
          t_employee.cpn_id = cpn_id_in ;
      END IF ;
    END IF ;
    SELECT result;
  END;
