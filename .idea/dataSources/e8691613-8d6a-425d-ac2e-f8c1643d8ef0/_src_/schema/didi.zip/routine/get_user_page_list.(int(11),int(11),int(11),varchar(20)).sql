CREATE PROCEDURE get_user_page_list(IN curr_page INT, IN page_size INT, IN u_state_s INT, IN u_name_s VARCHAR(20))
  BEGIN
    DECLARE s INT;
    SET s = (curr_page-1)*page_size;
    if u_state_s = 0 THEN
      SELECT * FROM t_user WHERE u_name LIKE concat('%',u_name_s,'%') ORDER BY u_name LIMIT s,page_size;
    ELSE SELECT * FROM t_user WHERE u_state = u_state_s AND
                                 u_name LIKE concat('%',u_name_s,'%') ORDER BY u_name LIMIT s, page_size;
    END IF ;
  END;
