CREATE PROCEDURE delete_car_by_id(IN c_id_in INT)
  BEGIN
    DECLARE result INT;
    if c_id_in IN (SELECT c_id FROM t_cpn_car) THEN
      DELETE FROM t_cpn_car WHERE c_id = c_id_in;
    END IF ;
    DELETE FROM t_car WHERE c_id = c_id_in;
    set result = row_count();

    SELECT result;
  END;
