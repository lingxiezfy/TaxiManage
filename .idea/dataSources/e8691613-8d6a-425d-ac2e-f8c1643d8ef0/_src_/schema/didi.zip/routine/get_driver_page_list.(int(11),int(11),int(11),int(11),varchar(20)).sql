CREATE PROCEDURE get_driver_page_list(IN cpn_id_in     INT, IN curr_page INT, IN page_size INT, IN d_state_s INT,
                                      IN d_real_name_s VARCHAR(20))
  BEGIN
  DECLARE s INT;
  SET s = (curr_page-1)*page_size;
  IF cpn_id_in = 0 THEN
    IF d_state_s = 0 THEN
      SELECT t_user.u_credit,t_driver.* FROM t_user,t_driver WHERE
        t_user.u_id = t_driver.u_id AND
        t_driver.d_real_name LIKE concat('%',d_real_name_s,'%') ORDER BY t_driver.d_real_name LIMIT s,page_size;
    ELSE
      SELECT t_user.u_credit,t_driver.* FROM t_user,t_driver WHERE
        t_user.u_id = t_driver.u_id AND t_driver.d_state = d_state_s AND
        t_driver.d_real_name LIKE concat('%',d_real_name_s,'%') ORDER BY t_driver.d_real_name LIMIT s,page_size;

    END IF ;
  ELSE
    IF d_state_s = 0 THEN
      SELECT t_user.u_credit,t_driver.* FROM t_user,t_driver,t_employee WHERE
        t_user.u_id = t_driver.u_id AND
        t_driver.d_real_name LIKE concat('%',d_real_name_s,'%') AND
          t_driver.u_id = t_employee.u_id AND
          t_employee.cpn_id = cpn_id_in ORDER BY
        t_driver.d_real_name LIMIT s,page_size;
    ELSE
      SELECT t_user.u_credit,t_driver.* FROM t_user,t_driver,t_employee WHERE
        t_user.u_id = t_driver.u_id AND
        t_driver.d_real_name LIKE concat('%',d_real_name_s,'%') AND
        t_driver.d_state = d_state_s AND
        t_driver.u_id = t_employee.u_id AND
        t_employee.cpn_id = cpn_id_in ORDER BY
        t_driver.d_real_name LIMIT s,page_size;
    END IF ;
  END IF ;
END;
