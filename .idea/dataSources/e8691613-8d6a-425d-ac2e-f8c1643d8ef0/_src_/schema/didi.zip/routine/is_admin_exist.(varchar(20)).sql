CREATE PROCEDURE is_admin_exist(IN a_count_in VARCHAR(20))
  BEGIN
    DECLARE result BOOLEAN;

    if((SELECT count(*) FROM t_admin WHERE a_count = trim(a_count_in))>0)
    THEN SET result = TRUE ;
    ELSE SET result=FALSE ;
    END IF ;
    SELECT result;
  END;
