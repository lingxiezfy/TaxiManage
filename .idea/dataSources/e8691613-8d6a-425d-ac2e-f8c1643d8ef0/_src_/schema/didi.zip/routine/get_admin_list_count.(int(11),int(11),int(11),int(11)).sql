CREATE PROCEDURE get_admin_list_count(IN a_id_in INT, IN a_t_id_in INT, IN cpn_id_in INT, IN a_t_id_s_in INT)
  BEGIN
    DECLARE result INT;
    if a_t_id_in < 3 THEN
      if a_t_id_s_in = 0 THEN
        SELECT count(*) INTO result FROM t_admin,t_a_type WHERE
          t_admin.a_t_id = t_a_type.a_t_id AND
          t_admin.a_t_id >= a_t_id_in AND
          t_admin.a_id != a_id_in ;
      ELSE
        SELECT count(*) into result FROM t_admin,t_a_type WHERE
          t_admin.a_t_id = t_a_type.a_t_id AND
          t_admin.a_t_id >= a_t_id_in AND
          t_admin.a_t_id = a_t_id_s_in AND
          t_admin.a_id != a_id_in ;
      END IF ;
    ELSE
      SELECT count(*) into result FROM t_admin,t_a_type,t_cpn_admin
      WHERE t_admin.a_t_id = t_a_type.a_t_id AND
            t_admin.a_id = t_cpn_admin.a_id AND
            t_cpn_admin.cpn_id = cpn_id_in AND
            t_admin.a_id != a_id_in ;
    END IF ;
    SELECT result;
  END;
