CREATE PROCEDURE get_car_page_list(IN cpn_id_in INT, IN curr_page INT, IN page_size INT, IN c_state_s INT,
                                   IN c_plant_s VARCHAR(20))
  BEGIN
    DECLARE s INT;
    SET s = (curr_page-1)*page_size;
    IF cpn_id_in = 0 THEN
      IF c_state_s = 0 THEN
        SELECT t_c_type.c_t_name,t_car.* FROM t_c_type,t_car WHERE
          t_c_type.c_t_id = t_car.c_t_id AND
          t_car.c_plate_number LIKE concat('%',c_plant_s,'%')
             ORDER BY t_car.c_t_id,t_car.c_brand,t_car.c_plate_number LIMIT s,page_size;
      ELSE
        SELECT t_c_type.c_t_name,t_car.* FROM t_c_type,t_car WHERE
          t_c_type.c_t_id = t_car.c_t_id AND
            t_car.c_state = c_state_s AND
          t_car.c_plate_number LIKE concat('%',c_plant_s,'%')
        ORDER BY t_car.c_t_id,t_car.c_brand,t_car.c_plate_number LIMIT s,page_size;
      END IF ;
    ELSE
      IF c_state_s = 0 THEN
        SELECT t_c_type.c_t_name,t_car.* FROM t_c_type,t_car,t_cpn_car WHERE
          t_c_type.c_t_id = t_car.c_t_id AND
            t_car.c_id = t_cpn_car.c_id AND
            t_cpn_car.cpn_id = cpn_id_in AND
          t_car.c_plate_number LIKE concat('%',c_plant_s,'%')
        ORDER BY t_car.c_t_id,t_car.c_brand,t_car.c_plate_number LIMIT s,page_size;
      ELSE
        SELECT t_c_type.c_t_name,t_car.* FROM t_c_type,t_car,t_cpn_car WHERE
          t_c_type.c_t_id = t_car.c_t_id AND
          t_car.c_state = c_state_s AND
          t_car.c_id = t_cpn_car.c_id AND
          t_cpn_car.cpn_id = cpn_id_in AND
          t_car.c_plate_number LIKE concat('%',c_plant_s,'%')
        ORDER BY t_car.c_t_id,t_car.c_brand,t_car.c_plate_number LIMIT s,page_size;

      END IF ;
    END IF ;
  END;
