CREATE PROCEDURE register_user(IN name_in    VARCHAR(20), IN pwd_in VARCHAR(15), IN phone_in VARCHAR(11),
                               IN id_card_in VARCHAR(18))
  BEGIN
    DECLARE result INT;
    INSERT INTO t_user(u_name, u_password, u_phone_number, u_id_card_number)
      VALUES (name_in,pwd_in,phone_in,id_card_in);
    SET result = row_count();
    SELECT result;
  END;
