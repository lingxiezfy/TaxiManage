CREATE PROCEDURE is_phone_exist(IN phone_in VARCHAR(20))
  BEGIN
    DECLARE result BOOLEAN;

    if((SELECT count(*) FROM t_user WHERE u_phone_number = trim(phone_in))>0)
    THEN SET result = TRUE ;
    ELSE SET result=FALSE ;
    END IF ;
    SELECT result;
  END;
