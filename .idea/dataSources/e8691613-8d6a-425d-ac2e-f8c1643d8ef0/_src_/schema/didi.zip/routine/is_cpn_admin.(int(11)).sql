CREATE PROCEDURE is_cpn_admin(IN a_id_in INT)
  BEGIN
    DECLARE result int;
    SET result = 0;
    if((SELECT count(*) FROM t_cpn_admin WHERE a_id = a_id_in) > 0)
    THEN 
      SELECT cpn_id FROM t_cpn_admin WHERE a_id = a_id_in INTO result;
    ELSE SET result = 0;
    END IF ;
    SELECT result;
  END;
