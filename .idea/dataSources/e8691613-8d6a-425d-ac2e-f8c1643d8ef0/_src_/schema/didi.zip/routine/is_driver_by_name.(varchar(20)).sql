CREATE PROCEDURE is_driver_by_name(IN u_name_in VARCHAR(20))
  BEGIN
    DECLARE id int;
    DECLARE result BOOLEAN;
    SET id = 0;
    SELECT u_id FROM t_user WHERE trim(u_name_in) = t_user.u_name into id;
    if((SELECT count(*) FROM t_driver WHERE id = t_driver.u_id)>0)
      THEN SET result = TRUE ;
    ELSE SET result=FALSE ;
    END IF ;
    SELECT result;
  END;
