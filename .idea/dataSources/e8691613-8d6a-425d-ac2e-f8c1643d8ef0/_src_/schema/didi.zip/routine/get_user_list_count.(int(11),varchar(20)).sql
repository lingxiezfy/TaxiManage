CREATE PROCEDURE get_user_list_count(IN u_state_s INT, IN u_name_s VARCHAR(20))
  BEGIN
    DECLARE result INT;
    if u_state_s = 0 THEN
      SELECT count(*) INTO result FROM t_user WHERE u_name LIKE concat('%',u_name_s,'%') ;
    ELSE SELECT count(*) INTO result FROM t_user WHERE u_state = u_state_s AND
                                    u_name LIKE concat('%',u_name_s,'%') ;
    END IF ;
    SELECT result;
  END;
