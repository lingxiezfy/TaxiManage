CREATE PROCEDURE delete_driver_by_id(IN u_id_in INT)
  BEGIN
    DECLARE result INT;
    if u_id_in IN (SELECT u_id FROM t_employee) THEN
      DELETE FROM t_employee WHERE u_id = u_id_in;
    END IF ;
    DELETE FROM t_driver WHERE u_id = u_id_in;
    set result = row_count();

    SELECT result;
  END;
