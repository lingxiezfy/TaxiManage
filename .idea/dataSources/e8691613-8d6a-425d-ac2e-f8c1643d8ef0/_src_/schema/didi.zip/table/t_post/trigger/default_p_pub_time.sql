CREATE TRIGGER default_p_pub_time
BEFORE INSERT ON t_post
FOR EACH ROW
  if new.p_pub_time is null then
    set new.p_pub_time = now();
  end if;
