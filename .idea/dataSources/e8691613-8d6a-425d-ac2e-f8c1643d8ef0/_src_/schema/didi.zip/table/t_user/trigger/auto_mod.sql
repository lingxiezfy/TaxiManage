CREATE TRIGGER auto_mod
BEFORE UPDATE ON t_user
FOR EACH ROW
  BEGIN
    if new.u_credit < 0 THEN
      SET new.u_credit = 0;
    END IF ;

    if new.u_credit < 80 then
      SET NEW.u_state = 2;
    end if ;
  END;
