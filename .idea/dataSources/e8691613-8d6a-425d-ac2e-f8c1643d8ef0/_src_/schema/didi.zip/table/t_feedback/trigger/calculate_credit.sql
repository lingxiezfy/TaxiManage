CREATE TRIGGER calculate_credit
BEFORE INSERT ON t_feedback
FOR EACH ROW
  if new.f_t_id = 3 AND new.f_target != 0 then
    UPDATE t_user SET u_credit = u_credit-1 WHERE t_user.u_id = NEW.f_target;
  end if;
