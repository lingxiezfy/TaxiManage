CREATE TRIGGER default_o_now_time
BEFORE INSERT ON t_order
FOR EACH ROW
  if new.o_now_time is null then
      set new.o_now_time = now();
    end if;
