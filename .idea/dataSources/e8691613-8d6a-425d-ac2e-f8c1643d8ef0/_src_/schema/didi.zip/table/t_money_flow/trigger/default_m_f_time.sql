CREATE TRIGGER default_m_f_time
BEFORE INSERT ON t_money_flow
FOR EACH ROW
  if new.m_f_time is null then
    set new.m_f_time = now();
  end if;
